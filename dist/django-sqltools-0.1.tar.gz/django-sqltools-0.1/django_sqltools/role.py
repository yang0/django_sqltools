# _*_coding:utf-8_*_

# 使用以下方法
# ROLE 跟 django auth_group 表的ID一致
# def RoleList():
#     return list(ROLE_DEFINED)

def RoleAdmin():
    """超级管理员"""
    return 1


def RoleOperator():
    """运营人员"""
    return 2


# def RoleUser():
#     """普通用户"""
#     return 4






